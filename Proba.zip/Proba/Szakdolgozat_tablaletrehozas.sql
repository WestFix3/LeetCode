-- 1. Ledobjuk a t�bl�kat (opcion�lis, de j� gyakorlat)
drop table ENEMY_SAVES;
drop table PLAYER_SAVES; -- El�sz�r a gyereket dobd, azt�n a sz�l�t!

SELECT * FROM PLAYER_SAVES;
SELECT * FROM ENEMY_SAVES;

-- 2. L�trehozzuk a Sz�l� (Player) t�bl�t
CREATE SEQUENCE player_saves_seq START WITH 1 INCREMENT BY 1; -- Ha haszn�ln�d a Sequence-t
CREATE TABLE PLAYER_SAVES (
    save_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, -- Ez a hivatkozott oszlop
    player_name VARCHAR2(100) NOT NULL,
    ability VARCHAR2(100),
    health NUMBER,
    max_health NUMBER,
    damage_boost NUMBER,
    crit_chance_boost NUMBER,
    save_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. L�trehozzuk a Gyermek (Enemy) t�bl�t
CREATE SEQUENCE enemy_saves_seq START WITH 1 INCREMENT BY 1; -- Ha haszn�ln�d a Sequence-t
CREATE TABLE ENEMY_SAVES (
    save_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    -- IDEGEN KULCS OSZLOP
    player_save_id NUMBER NOT NULL,
    enemy_name VARCHAR2(100),
    health NUMBER,
    damage NUMBER,
    speed NUMBER,
    is_boss NUMBER(1) DEFAULT 0,
    save_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- IDEGEN KULCS MEGK�T�S (REFERENCES a m�r l�tez� PLAYER_SAVES-re)
    FOREIGN KEY (player_save_id) REFERENCES PLAYER_SAVES(save_id)
);